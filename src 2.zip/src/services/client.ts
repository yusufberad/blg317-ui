import HttpService from "./http";
export const clientSahmat = new HttpService({
  baseUrl: "http://localhost:5001",
});
